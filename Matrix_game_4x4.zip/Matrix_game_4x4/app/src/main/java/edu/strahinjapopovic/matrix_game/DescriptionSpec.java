package edu.strahinjapopovic.matrix_game;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by Strahinja on 6/20/2016.
 */
public class DescriptionSpec extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.description_spec);

        final Button btnPrev = (Button) findViewById(R.id.btnPrevious);
        final Button btnHome = (Button) findViewById(R.id.btnHome);

        btnPrev.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                try
                {
                    onBackPressed();
                }
                catch (Exception ex)
                {
                    Toast.makeText(getApplicationContext(), ex.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

        btnHome.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent i = new Intent();
                i = new Intent(DescriptionSpec.this, MainGameActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        Intent i;
        switch(item.getItemId())
        {
            case R.id.mainMenuActivity:
                i = new Intent(this, MainGameActivity.class);
                startActivity(i);
                return true;

            case R.id.description:
                i = new Intent(this, DescriptionActivity.class);
                startActivity(i);
                return true;

            case R.id.description_plus2:
                i = new Intent(this, DescriptionPlus2Activity.class);
                startActivity(i);
                return true;

            case R.id.description_plus3:
                i = new Intent(this, DescriptionPlus3Activity.class);
                startActivity(i);
                return true;

            case R.id.description_specification:
                i = new Intent(this, DescriptionSpec.class);
                startActivity(i);
                return true;
        }
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.description_plus1_menu, menu);
        return true;
    }
}
