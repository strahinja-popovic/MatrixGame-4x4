package edu.strahinjapopovic.matrix_game;

public class Item
{
	private int RDC;
	int state=0;
	
	public Item(int rdc, String title) 
	{
		this.setRDC(rdc);
	}
	
	int getRDC() 
	{
		return RDC;
	}
	
	void setRDC(int rDC) 
	{
		RDC = rDC;
	}
	
	public int nextColor()
	{
		RDC = R.drawable.grey;
		if(++state > 3)state = 1;
		
		switch(state)
		{
			case 1:
				RDC = R.drawable.blue;
				break;
			case 2:
				RDC = R.drawable.white;
				break;
			case 3:
				RDC = R.drawable.grey;
				break;
		}
		return RDC;
	}
}
