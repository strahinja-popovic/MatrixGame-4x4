package edu.strahinjapopovic.matrix_game;

import java.util.Random;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class MainGameActivity extends Activity
{
	GridView gridView;
	Item[] gridArray = new Item[16];
	ImageAdapter iAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_game_layout);

		final long startTime = System.currentTimeMillis();

		final TextView txtTime = (TextView) findViewById(R.id.txtTime);

		for(int i = 0; i< 16; i++)
		{
			Random random = new Random();
			int number_1;
			int number_2;

			number_1 = random.nextInt(4);
			number_2 = random.nextInt(8);

			if(i == number_1)
			{
				gridArray[number_1] = new Item(R.drawable.blue,"blue");
			}
			else if(i == number_2)
			{
				gridArray[number_2] = new Item(R.drawable.white,"white");
			}
			else
			{
				gridArray[i] = new Item(R.drawable.grey,"grey");
			}
		}

		GridView gridview = (GridView) findViewById(R.id.gridView);
		iAdapter = new ImageAdapter(this, gridArray);
		gridview.setAdapter(iAdapter);

		final TextView txtMessage = (TextView) findViewById(R.id.txtMessage);

		final Button newGameButton = (Button) findViewById(R.id.newGameButton);
		newGameButton.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				Intent i = new Intent();
				i.setClass(MainGameActivity.this, MainGameActivity.class);
				startActivity(i);
			}
		});

		final Button evaluationButton = (Button) findViewById(R.id.evaluationButton);
		evaluationButton.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				if (gridArray[0].getRDC() == R.drawable.grey || gridArray[1].getRDC() == R.drawable.grey ||
				gridArray[2].getRDC() == R.drawable.grey || gridArray[3].getRDC() == R.drawable.grey ||
				gridArray[4].getRDC() == R.drawable.grey || gridArray[5].getRDC() == R.drawable.grey ||
				gridArray[6].getRDC() == R.drawable.grey || gridArray[7].getRDC() == R.drawable.grey ||
				gridArray[8].getRDC() == R.drawable.grey || gridArray[9].getRDC() == R.drawable.grey ||
				gridArray[10].getRDC() == R.drawable.grey || gridArray[11].getRDC() == R.drawable.grey ||
				gridArray[12].getRDC() == R.drawable.grey || gridArray[13].getRDC() == R.drawable.grey ||
				gridArray[14].getRDC() == R.drawable.grey || gridArray[15].getRDC() == R.drawable.grey)
				{
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.RED);
					txtMessage.setText("All fields need to be blue OR white. We need 2(b)x2(w) color fields alternately horizontal OR vertical.");
				}
				else
				{
					if (
					/* Horizontal evaluation for blue fields */
					((gridArray[0].getRDC() == R.drawable.blue && gridArray[1].getRDC() == R.drawable.blue &&
					gridArray[2].getRDC() == R.drawable.blue) || (gridArray[1].getRDC() == R.drawable.blue &&
					gridArray[2].getRDC() == R.drawable.blue && gridArray[3].getRDC() == R.drawable.blue) ||
					(gridArray[4].getRDC() == R.drawable.blue && gridArray[5].getRDC() == R.drawable.blue &&
					gridArray[6].getRDC() == R.drawable.blue) || (gridArray[5].getRDC() == R.drawable.blue &&
					gridArray[6].getRDC() == R.drawable.blue && gridArray[7].getRDC() == R.drawable.blue) ||
					(gridArray[8].getRDC() == R.drawable.blue && gridArray[9].getRDC() == R.drawable.blue &&
					gridArray[10].getRDC() == R.drawable.blue) || (gridArray[9].getRDC() == R.drawable.blue &&
					gridArray[10].getRDC() == R.drawable.blue && gridArray[11].getRDC() == R.drawable.blue) ||
					(gridArray[12].getRDC() == R.drawable.blue && gridArray[13].getRDC() == R.drawable.blue &&
					gridArray[14].getRDC() == R.drawable.blue) || (gridArray[13].getRDC() == R.drawable.blue &&
					gridArray[14].getRDC() == R.drawable.blue && gridArray[15].getRDC() == R.drawable.blue) ||
					/* Vertical evaluation for blue fields */
					(gridArray[0].getRDC() == R.drawable.blue && gridArray[4].getRDC() == R.drawable.blue &&
					gridArray[8].getRDC() == R.drawable.blue) || (gridArray[4].getRDC() == R.drawable.blue &&
					gridArray[8].getRDC() == R.drawable.blue && gridArray[12].getRDC() == R.drawable.blue) ||
					(gridArray[1].getRDC() == R.drawable.blue && gridArray[5].getRDC() == R.drawable.blue &&
					gridArray[9].getRDC() == R.drawable.blue) || (gridArray[5].getRDC() == R.drawable.blue &&
					gridArray[9].getRDC() == R.drawable.blue && gridArray[13].getRDC() == R.drawable.blue) ||
					(gridArray[2].getRDC() == R.drawable.blue && gridArray[6].getRDC() == R.drawable.blue &&
					gridArray[10].getRDC() == R.drawable.blue) || (gridArray[6].getRDC() == R.drawable.blue &&
					gridArray[10].getRDC() == R.drawable.blue && gridArray[14].getRDC() == R.drawable.blue) ||
					(gridArray[3].getRDC() == R.drawable.blue && gridArray[7].getRDC() == R.drawable.blue &&
					gridArray[11].getRDC() == R.drawable.blue) || (gridArray[7].getRDC() == R.drawable.blue &&
					gridArray[11].getRDC() == R.drawable.blue && gridArray[15].getRDC() == R.drawable.blue)) ||
					/* Horizontal evaluation for white fields */
					((gridArray[0].getRDC() == R.drawable.white && gridArray[1].getRDC() == R.drawable.white &&
					gridArray[2].getRDC() == R.drawable.white) || (gridArray[1].getRDC() == R.drawable.white &&
					gridArray[2].getRDC() == R.drawable.white && gridArray[3].getRDC() == R.drawable.white) ||
					(gridArray[4].getRDC() == R.drawable.white && gridArray[5].getRDC() == R.drawable.white &&
					gridArray[6].getRDC() == R.drawable.white) || (gridArray[5].getRDC() == R.drawable.white &&
					gridArray[6].getRDC() == R.drawable.white && gridArray[7].getRDC() == R.drawable.white) ||
					(gridArray[8].getRDC() == R.drawable.white && gridArray[9].getRDC() == R.drawable.white &&
					gridArray[10].getRDC() == R.drawable.white) || (gridArray[9].getRDC() == R.drawable.white &&
					gridArray[10].getRDC() == R.drawable.white && gridArray[11].getRDC() == R.drawable.white) ||
					(gridArray[12].getRDC() == R.drawable.white && gridArray[13].getRDC() == R.drawable.white &&
					gridArray[14].getRDC() == R.drawable.white) || (gridArray[13].getRDC() == R.drawable.white &&
					gridArray[14].getRDC() == R.drawable.white && gridArray[15].getRDC() == R.drawable.white) ||
					/* Vertical evaluation for white fields */
					(gridArray[0].getRDC() == R.drawable.white && gridArray[4].getRDC() == R.drawable.white &&
					gridArray[8].getRDC() == R.drawable.white) || (gridArray[4].getRDC() == R.drawable.white &&
					gridArray[8].getRDC() == R.drawable.white && gridArray[12].getRDC() == R.drawable.white) ||
					(gridArray[1].getRDC() == R.drawable.white && gridArray[5].getRDC() == R.drawable.white &&
					gridArray[9].getRDC() == R.drawable.white) || (gridArray[5].getRDC() == R.drawable.white &&
					gridArray[9].getRDC() == R.drawable.white && gridArray[13].getRDC() == R.drawable.white) ||
					(gridArray[2].getRDC() == R.drawable.white && gridArray[6].getRDC() == R.drawable.white &&
					gridArray[10].getRDC() == R.drawable.white) || (gridArray[6].getRDC() == R.drawable.white &&
					gridArray[10].getRDC() == R.drawable.white && gridArray[14].getRDC() == R.drawable.white) ||
					(gridArray[3].getRDC() == R.drawable.white && gridArray[7].getRDC() == R.drawable.white &&
					gridArray[11].getRDC() == R.drawable.white) || (gridArray[7].getRDC() == R.drawable.white &&
					gridArray[11].getRDC() == R.drawable.white && gridArray[15].getRDC() == R.drawable.white)))
					{
						txtMessage.setTextSize(20);
						txtMessage.setTextColor(Color.RED);
						txtMessage.setText("More than 2 same color fields side by side. Alternately 1(b)x1(w) OR more than 2(b)x2(w) fields are not valid to finish.");
					}
					else
					{
						if(
						//Vertical variant No 1
						(gridArray[0].getRDC() == R.drawable.blue && gridArray[1].getRDC() == R.drawable.white &&
						gridArray[2].getRDC() == R.drawable.blue && gridArray[3].getRDC() == R.drawable.white &&
						gridArray[4].getRDC() == R.drawable.blue && gridArray[5].getRDC() == R.drawable.white &&
						gridArray[6].getRDC() == R.drawable.blue && gridArray[7].getRDC() == R.drawable.white &&
						gridArray[8].getRDC() == R.drawable.white && gridArray[9].getRDC() == R.drawable.blue &&
						gridArray[10].getRDC() == R.drawable.white && gridArray[11].getRDC() == R.drawable.blue &&
						gridArray[12].getRDC() == R.drawable.white && gridArray[13].getRDC() == R.drawable.blue &&
						gridArray[14].getRDC() == R.drawable.white && gridArray[15].getRDC() == R.drawable.blue) ||
						//Vertical variant No 2
						(gridArray[0].getRDC() == R.drawable.white && gridArray[1].getRDC() == R.drawable.blue &&
						gridArray[2].getRDC() == R.drawable.white && gridArray[3].getRDC() == R.drawable.blue &&
						gridArray[4].getRDC() == R.drawable.white && gridArray[5].getRDC() == R.drawable.blue &&
						gridArray[6].getRDC() == R.drawable.white && gridArray[7].getRDC() == R.drawable.blue &&
						gridArray[8].getRDC() == R.drawable.blue && gridArray[9].getRDC() == R.drawable.white &&
						gridArray[10].getRDC() == R.drawable.blue && gridArray[11].getRDC() == R.drawable.white &&
						gridArray[12].getRDC() == R.drawable.blue && gridArray[13].getRDC() == R.drawable.white &&
						gridArray[14].getRDC() == R.drawable.blue && gridArray[15].getRDC() == R.drawable.white) ||
						//Horizontal variant No 1
						(gridArray[0].getRDC() == R.drawable.blue && gridArray[1].getRDC() == R.drawable.blue &&
						gridArray[2].getRDC() == R.drawable.white && gridArray[3].getRDC() == R.drawable.white &&
						gridArray[4].getRDC() == R.drawable.white && gridArray[5].getRDC() == R.drawable.white &&
						gridArray[6].getRDC() == R.drawable.blue && gridArray[7].getRDC() == R.drawable.blue &&
						gridArray[8].getRDC() == R.drawable.blue && gridArray[9].getRDC() == R.drawable.blue &&
						gridArray[10].getRDC() == R.drawable.white && gridArray[11].getRDC() == R.drawable.white &&
						gridArray[12].getRDC() == R.drawable.white && gridArray[13].getRDC() == R.drawable.white &&
						gridArray[14].getRDC() == R.drawable.blue && gridArray[15].getRDC() == R.drawable.blue) ||
						//Horizontal variant No 2
						(gridArray[0].getRDC() == R.drawable.white && gridArray[1].getRDC() == R.drawable.white &&
						gridArray[2].getRDC() == R.drawable.blue && gridArray[3].getRDC() == R.drawable.blue &&
						gridArray[4].getRDC() == R.drawable.blue && gridArray[5].getRDC() == R.drawable.blue &&
						gridArray[6].getRDC() == R.drawable.white && gridArray[7].getRDC() == R.drawable.white &&
						gridArray[8].getRDC() == R.drawable.white && gridArray[9].getRDC() == R.drawable.white &&
						gridArray[10].getRDC() == R.drawable.blue && gridArray[11].getRDC() == R.drawable.blue &&
						gridArray[12].getRDC() == R.drawable.blue && gridArray[13].getRDC() == R.drawable.blue &&
						gridArray[14].getRDC() == R.drawable.white && gridArray[15].getRDC() == R.drawable.white))
						{
							//FINAL EXECUTION
							final long endTime = System.currentTimeMillis();
							long estimatedTime = endTime - startTime;
							long seconds = estimatedTime / 1000;
							long minutes;
							long hours;
							//estimatedTime = System.currentTimeMillis();

							if (seconds > 0 && seconds < 60)
							{
								if (seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:00:0" + estimatedTime / 1000);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + estimatedTime / 1000 + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable()
									{
										@Override
										public void run()
										{
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:00:" + estimatedTime / 1000);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + estimatedTime / 1000 + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable()
									{
										@Override
										public void run()
										{
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
							}
							else if ((seconds >= 60) && ((seconds / 60) < 60))
							{
								minutes = seconds / 60;
								seconds = seconds % 60;

								if (minutes < 10 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:0" + minutes + ":00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + minutes + " m/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (minutes < 10 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:0" + minutes + ":0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + minutes + " m/ " + seconds + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run()
										{
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (minutes < 10 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:0" + minutes + ":" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + minutes + " m/ " + seconds + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (minutes >= 10 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:" + minutes + ":00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + minutes + " m/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (minutes >= 10 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:" + minutes + ":0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + minutes + " m/ " + seconds + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (minutes >= 10 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 00:" + minutes + ":" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + minutes + " m/ " + seconds + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
							}
							else if ((seconds / 60) >= 60)
							{
								hours = seconds / 3600;
								minutes = (seconds / 60) % 60;
								seconds = seconds % 60;

								if (hours < 10 && minutes == 0 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":00:00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ 0 m/ 0 s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes < 10 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":0" + minutes + ":00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes == 0 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":00:0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ 0 m/ " + seconds + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes < 10 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":0" + minutes + ":0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ " + seconds + " s/");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes >= 10 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":" + minutes + ":00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes == 0 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":00:" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ 0 m/" + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes < 10 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":0" + minutes + ":" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/" + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes >= 10 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":" + minutes + ":0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/" + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours < 10 && minutes >= 10 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) 0" + hours + ":" + minutes + ":" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/" + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes == 0 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":00:00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ 0 m/ 0 s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes < 10 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":0" + minutes + ":00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ 0 s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes == 0 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":00:0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ 0 m/ " + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes == 0 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":00:" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ 0 m/ " + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes >= 10 && seconds == 0)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":" + minutes + ":00");
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ 0 s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes < 10 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":0" + minutes + ":0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ " + seconds + "  s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes < 10 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":0" + minutes + ":" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ " + seconds + "  s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes >= 10 && seconds < 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":" + minutes + ":0" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ " + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
								else if (hours >= 10 && minutes >= 10 && seconds >= 10)
								{
									txtTime.setTextSize(20);
									txtTime.setTextColor(Color.BLUE);
									txtTime.setTypeface(null, Typeface.BOLD);
									txtTime.setText("Time (h:m:s) " + hours + ":" + minutes + ":" + seconds);
									txtMessage.setTextSize(20);
									txtMessage.setTextColor(Color.BLUE);
									txtMessage.setTypeface(null, Typeface.BOLD);
									txtMessage.setText("You win this game in: / " + hours + " h/ " + minutes + " m/ " + seconds + " s/ ");
									Handler handler = new Handler();
									handler.postDelayed(new Runnable() {
										@Override
										public void run() {
											Intent i = new Intent();
											i.setClass(MainGameActivity.this, MainGameActivity.class);
											startActivity(i);
										}
									}, 3000);
								}
							}
						}
						else
						{
							txtMessage.setTextSize(20);
							txtMessage.setTextColor(Color.RED);
							txtMessage.setText("We need 2(b)x2(w) fields alternately horizontal OR vertical. Alternately 1(b)x1(w) OR more than 2(b)x2(w) are not valid to finish.");
						}
					}
				}
			}
		});

		gridview.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
				int c = gridArray[position].nextColor();
				((ImageView) v).setImageResource(c);

				if ((position + 1) <= 4 && gridArray[position].getRDC() == R.drawable.blue) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (1," + (position + 1) + ") -> is Blue!");
				} else if ((position + 1) <= 8 && gridArray[position].getRDC() == R.drawable.blue) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (2," + (position - 3) + ") -> is Blue!");
				} else if ((position + 1) <= 12 && gridArray[position].getRDC() == R.drawable.blue) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (3," + (position - 7) + ") -> is Blue!");
				} else if ((position + 1) <= 16 && gridArray[position].getRDC() == R.drawable.blue) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (4," + (position - 11) + ") -> is Blue!");
				} else if ((position + 1) <= 4 && gridArray[position].getRDC() == R.drawable.grey) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (1," + (position + 1) + ") -> is Grey!");
				} else if ((position + 1) <= 8 && gridArray[position].getRDC() == R.drawable.grey) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (2," + (position - 3) + ") -> is Grey!");
				} else if ((position + 1) <= 12 && gridArray[position].getRDC() == R.drawable.grey) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [" + (position + 1) + "] = Mx (3," + (position - 7) + ") -> is Grey!");
				} else if ((position + 1) <= 16 && gridArray[position].getRDC() == R.drawable.grey) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (4," + (position - 11) + ") -> is Grey!");
				} else if ((position + 1) <= 4 && gridArray[position].getRDC() == R.drawable.white) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (1," + (position + 1) + ") -> is White!");
				} else if ((position + 1) <= 8 && gridArray[position].getRDC() == R.drawable.white) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (2," + (position - 3) + ") -> is White!");
				} else if ((position + 1) <= 12 && gridArray[position].getRDC() == R.drawable.white) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (3," + (position - 7) + ") -> is White!");
				} else if ((position + 1) <= 16 && gridArray[position].getRDC() == R.drawable.white) {
					txtMessage.setTextSize(20);
					txtMessage.setTextColor(Color.BLUE);
					txtMessage.setText("Field P [ " + (position + 1) + " ] = Mx (4," + (position - 11) + ") -> is White!");
				}
			}
		});
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		Intent i;
		switch(item.getItemId())
		{
			case R.id.description:
				i = new Intent(this, DescriptionActivity.class);
				startActivity(i);
				return true;

			case R.id.description_plus1:
				i = new Intent(this, DescriptionPlus1Activity.class);
				startActivity(i);
				return true;

			case R.id.description_plus2:
				i = new Intent(this, DescriptionPlus2Activity.class);
				startActivity(i);
				return true;

			case R.id.description_plus3:
				i = new Intent(this, DescriptionPlus3Activity.class);
				startActivity(i);
				return true;

			case R.id.description_specification:
				i = new Intent(this, DescriptionSpec.class);
				startActivity(i);
				return true;
		}
		return false;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_game_menu, menu);
		return true;
	}
}
